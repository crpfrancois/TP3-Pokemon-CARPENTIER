<template>
  <div id="app">
    <select v-model="selectedGeneration" @change="fetchPokemonsByGeneration"></select>
    <input type="number" v-model="pokemonCount" placeholder="Nombre de Pokémon" />
    <button @click="fetchPokemons">Charger</button>
    <select v-model="selectedGeneration" @change="fetchPokemonsByGeneration">
      <option value="1">Génération 1</option>
      <option value="2">Génération 2</option>
      <option value="3">Génération 3</option>
      <option value="4">Génération 4</option>
      <option value="5">Génération 5</option>
      <option value="6">Génération 6</option>
      <option value="7">Génération 7</option>
      <option value="8">Génération 8</option>
    </select>
    <ListeTypesPokemon :pokemons="pokemons" />
    <Pokedex :pokemons="pokemons" />
    <Footer />
  </div>
</template>

<script>
import axios from 'axios';
import Pokedex from './components/Pokedex.vue';
import Footer from './components/Footer.vue';
import ListeTypesPokemon from './components/ListeTypesPokemon.vue';

export default {
  name: 'App',
  components: {
    Pokedex,
    Footer,
    ListeTypesPokemon
  },
  data() {
    return {
      pokemons: [],
      selectedGeneration: '1',
      pokemonCount: 20
    };
  },
  methods: {
    async fetchPokemons() {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/limit/${this.pokemonCount}`);
        this.pokemons = response.data;
      } catch (error) {
        console.error("Erreur lors de la récupération des données des Pokémon:", error);
      }
    },
    async fetchPokemonsByGeneration() {
      try {
        const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/generation/${this.selectedGeneration}`);
        this.pokemons = response.data.slice(0, this.pokemonCount);
      } catch (error) {
        console.error("Erreur lors de la récupération des Pokémon de la génération:", error);
      }
    }
  },
  created() {
    this.fetchPokemons();
  }
};
</script>



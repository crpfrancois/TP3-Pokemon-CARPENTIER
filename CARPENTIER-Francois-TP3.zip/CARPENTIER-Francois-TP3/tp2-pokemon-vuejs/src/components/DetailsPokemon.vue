<template>
    <div class="pokemon-details" v-if="pokemon">
        <h1>{{ pokemon.name }}</h1>
        <!-- Ajoutez plus de détails ici selon les données disponibles -->
    </div>
</template>
  
<script>
import axios from 'axios';

export default {
    name: 'DetailsPokemon',
    data() {
        return {
            pokemon: null
        };
    },
    async created() {
        try {
            const response = await axios.get(`https://pokebuildapi.fr/api/v1/pokemon/${this.$route.params.id}`);
            this.pokemon = response.data;
        } catch (error) {
            console.error("Erreur lors de la récupération des détails du Pokémon:", error);
        }
    }
};
</script>
  
<style scoped>
.pokemon-details {
    margin: 1rem;
    padding: 1rem;
    border: 1px solid #ccc;
    border-radius: 5px;
}
</style>
<template>
    <footer class="footer">
        <p>CARPENTIER François TP B</p>
    </footer>
</template>
  
<script>
export default {
    name: 'Footer'
};
</script>
  
<style scoped>
.footer {
    position: relative;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #333;
    color: black;
    text-align: center;
    padding: 1rem 0;
}
</style>
<template>
    <div class="pokemon-card" :style="{ backgroundColor: backgroundColor }">
        <div @click="goToDetails(pokemon.id)"></div>
        <img :src="pokemon.image" :alt="pokemon.name" />
        <h2>{{ pokemon.name }}</h2>
        <div class="types">
            <div v-for="type in pokemon.apiTypes" :key="type.name" class="type">
                <img :src="type.image" :alt="type.name" />
                <span>{{ type.name }}</span>
            </div>
        </div>
        <p>Generation: {{ pokemon.apiGeneration }}</p>
    </div>
</template>
  
<script>
export default {
    name: 'PokemonCard',
    props: {
        pokemon: {
            type: Object,
            required: true
        }
    },
    computed: {
        backgroundColor() {
            const type = this.pokemon.apiTypes[0].name.toLowerCase();
            return this.typeToColor(type);
        }
    },
    methods: {
        goToDetails(id) {
            this.$router.push({ name: 'DetailsPokemon', params: { id: id } });
        },
        goToDetails(id) {
            this.$router.push({ name: 'DetailsPokemon', params: { id: id } });
        },

        typeToColor(type) {
            const colors = {
                plante: '#78C850',
                feu: '#F08030',
                eau: '#6890F0',
                électrik: '#F8D030',
                glace: '#98D8D8',
                combat: '#C03028',
                poison: '#A040A0',
                sol: '#E0C068',
                vol: '#A890F0',
                psy: '#F85888',
                insecte: '#A8B820',
                roche: '#B8A038',
                spectre: '#705898',
                dragon: '#7038F8',
                tenebres: '#705848',
                acier: '#B8B8D0',
                fée: '#EE99AC',
                normal: '#A8A878'

            };
            return colors[type] || '#FFFFFF';
        }
    }
};
</script>
  
<style scoped>
img {
    max-width: 100%;
    height: auto;
}

.pokemon-card {
    margin: 5px;
    width: 30%;
    height: auto;
    border-radius: 10px;
}

.pokemon-card h2 {
    color: #FFF;
    font-size: 2em;
    text-transform: capitalize;
    text-align: center;
}

.pokemon-card p {
    color: #FFF;
    font-size: 1.5em;
    text-transform: capitalize;
    text-align: center;
}

.pokemon-card .types {
    display: flex;
    justify-content: center;
    color: #FFF;
    font-size: 1.5em;
}
</style>
  